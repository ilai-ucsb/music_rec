import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='ilai01',
    application_name='flask-api-serverless',
    app_uid='8BgWvsL3K7XBBCvFWb',
    org_uid='cd4336d9-fd52-4111-b438-7ab0c36b62bd',
    deployment_uid='6957604c-1730-42eb-a8c2-8c33e33643d7',
    service_name='flask-api-serverless',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='6.2.3',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'flask-api-serverless-dev-api', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('wsgi_handler.handler')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
